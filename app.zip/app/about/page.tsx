import Footer from "@/components/footer"
import Header from "@/components/header"

export default function AboutPage() {
  return (
    <>
      <Header />
      <main id="main">
      <section id="about" className="section">
        <div className="container prose">
          <h2 className="caps">About</h2>
          <p>
            We streamline the knitwear process with no minimums, no delays, and no compromises. 
            Our end-to-end model connects designers with expert technicians, bridging the gap 
            between concept and production through precision, speed, and craft.
          </p>
          <p>
            At MAEKNIT, we bring advanced knitting technology, zero-waste labs, and expert 
            support to help brands move from sketch to shelf in record time. Our team of 
            knitwear designers, programmers, and technicians partner with you at every step, 
            from first prototype to scalable production.
          </p>
          <h3 className="caps">Reshoring with Intention</h3>
          <p>
            With laboratories in <strong>New York</strong> and <strong>London</strong> and 
            a global production network, we bring technical excellence back to the center 
            of fashion. We don’t just accelerate timelines — we redesign the system. 
            Transparent, responsive, and built to match the rhythm of modern design.
          </p>
          <p>
            We collaborate with brands, retailers and emerging designers to bring ideas to life — 
            whether it’s a single sample or a full collection. Every piece we produce reflects 
            discipline, care, and a lifetime of experience.
          </p>
          <p>
            We manage the complexity behind the scenes, so you receive exactly what you envisioned — 
            on time, at scale, without compromise. Delivered to your studio, showroom, or doorstep.
          </p>
        </div>
      </section>

      </main>
      <Footer />
    </>
  )
}
