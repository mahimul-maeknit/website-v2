export { default } from "./footer"
